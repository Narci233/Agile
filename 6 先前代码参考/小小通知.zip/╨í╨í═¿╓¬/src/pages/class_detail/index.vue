<template>
  <div>
    <div class="img">
    </div>
    <div class="text">
      <div class="coursename" >
      <p >{{course_name}}</p>
      
      </div>
      
      <p>{{course_teacher}}</p>
      <br>
      <br>
      <div class="description">
        <p>{{course_description}}</p>
      </div>
      <br>
    </div>
    <div class='btn'>
        <button @click="join">收藏该项目</button>
        <button @click="enter_course()">进入该项目</button>
    </div>
  </div>
</template>


<script>
export default {
  data() {
    return {
      course_id: "",
      course_name: "",
      course_teacher: "",
      course_description: "",
      openid: wx.getStorageSync("openid")
    };
  },

  methods: {
    enter_course() {
      var that = this;
      setTimeout(function() {
        wx.navigateTo({
          url: "/pages/assignment/main?course_id=" + that.course_id
        });
      }, 1500);
    },
    join() {
      var db = wx.cloud.database();
      var my_courses = db.collection("my_courses");
      var that = this;

      my_courses
        .where({
          _openid: that.openid,
          course_id: that.course_id
        })
        .get({
          success: function(res) {
            var length = res.data.length;
            if (length == 0) {
              my_courses.add({
                data: {
                  course_id: that.course_id,
                  course: that.course_name
                }
              });
              wx.showToast({
                title: "加入成功",
                duration: 1500
              });
            } else {
              wx.showModal({
                title: "提示",
                content: "已加入该项目",
                showCancel: false
              });
            }
          }
        });
    }
  },

  onLoad(option) {
    this.course_id = option.course_id;
    this.course_name = "";
    this.course_teacher = "";
    this.course_description = ""
  },
  onShow() {
    wx.cloud.init();
    var db = wx.cloud.database();
    var that = this;
    db
      .collection("courses")
      .where({
        _id: that.course_id
      })
      .get({
        success: function(res) {
          that.course_name = res.data[0].course;
          that.course_teacher = res.data[0].teacher;
          that.course_description = res.data[0].description;
        }
      });
  }
};
</script>

<style scoped>
.coursename{
  font-weight:bold;
  margin-bottom:5%;
}
.description{
  margin-top:5%;
  margin-left:15%;
  margin-right:15%;
}
.img {
    width: 380px;
    height:680px;
    background-image: url("https://7061-para-719569-1259337709.tcb.qcloud.la/bg3.jpg?sign=53548159d6b53f70cab3ad3b018d107b&t=1562226080");
    background-size: 100%;
    background-repeat: repeat-y;
    position: absolute;
    z-index:1;
  }
.text{
  font-family:Dengxian;
  text-align:center;    
  position: relative;
    z-index:9999;
    color:#fff;
}


button::after{
  border: 1px solid #fff;
  position: relative;
  z-index:9999;
  border-bottom:none;
  border-left:none;
  border-top:none;
  border-right:none;
}

button{
  border-radius:30px 30px 30px 30px;
  color:#fff;
  border: 1px dashed #fff;
  background-color: #63a2d5;
  size:10%;
  width:200px;
  margin-top:5%;
  font-size:30rpx;
  position: relative;
  z-index:9999;
  font-size:32rpx;
}
</style>

