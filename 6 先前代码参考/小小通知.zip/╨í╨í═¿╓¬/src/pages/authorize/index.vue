<template>
  <div>
    <div class="info">
      <p>
          登陆后应用将获得以下权限
      </p>
      <p>
          获得你的公开信息（昵称、头像等）
      </p>
    </div>
    
    <div class="img">
    </div>

    <button open-type='getUserInfo' @getuserinfo="getUserInfo">授权</button>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },

  methods: {
    getUserInfo: function(e) {
      if (e.mp.detail.userInfo) {
        var nickName = e.mp.detail.userInfo.nickName;
        var userInfoAvatar = e.mp.detail.userInfo.avatarUrl;
        var province = e.mp.detail.userInfo.province;
        var city = e.mp.detail.userInfo.city;
        var items = {
          name: nickName,
          img: userInfoAvatar,
          province: province,
          city: city
        };
        wx.setStorageSync("users", items);
        // console.log(wx.getStorageSync("users"))
        wx.switchTab({ url: "/pages/index/main" });
        console.log("yeah");
      } else {
        wx.showModal({
          title: "警告",
          content:
            "您点击了拒绝授权,将无法正常显示个人信息,点击确定重新获取授权。",
          showCancel: false
        });
      }
    }
  },
  onShow() {
    if (wx.getStorageSync("users")) {
      wx.switchTab({ url: "/pages/index/main"})
    }
  }
};
</script>

<style scoped>
div{
  z-index:9999;
  position:relative;
}
.info{
  font-family:Dengxian;
  margin-left:60px;
  margin-top:150px;
  text-align:center;
  z-index:9999;
  position:absolute;
  color:white;
}
.img {
    position: absolute;
    width: 380px;
    height:680px;
    background-image: url("https://7061-para-719569-1259337709.tcb.qcloud.la/bg3.jpg?sign=92e3d4589f230b950ac1ae8b8ea20334&t=1562201460");
    background-size: 100%;
    background-repeat: no-repeat;
    z-index:1;
    margin:-20% 0 0 0;
  }
button::after{

  border:1px solid #fff;
}
input{
  text-align:center;
  outline:none;
  border:none;
  list-style: none;
}
button{
  font-family:Dengxian;
  background-color:transparent;
  margin:60% 40%;
  color:#fff;
  border: none; 
  z-index:9999;
  position:absolute;
}
</style>
