<template> 
  <div> 
      <div class="img">
      </div>
      <div class="search">
        <textarea placeholder-style="border-radius:10px;color:white;font-size:18px" v-model="search_content" placeholder="请输入通知名称" />
        <button id="search"  @click="search">搜索</button>
        <button id="fresh" @click="fresh">显示所有通知</button>
        <button id="backhome" @click="backhome()">返回主页</button>
      </div>
      
       <image src="/static/images/5.png" @click="addAssignment" />
      <div v-for="(homework,index) in homeworkData" :key="index">
        <div id="card" class="weui-form-preview">
            <div id="card-header" class="weui-form-preview__hd">
                <div class="weui-form-preview__item">
                    <div class="weui-form-preview__label">通知名称</div>
                    <div class="weui-form-preview__value_in-hd">{{homework.name}}</div>
                </div>
            </div>
            <div class="weui-form-preview__bd">
                <div class="weui-form-preview__item">
                    <div class="weui-form-preview__label">截止时间</div>
                    <div class="weui-form-preview__value">{{homework.ddl}}</div>
                </div>
            </div>
            <div class="weui-form-preview__ft">
                <div class="weui-form-preview__btn1 weui-form-preview__btn_default" hover-class="weui-form-preview__btn_active" @click="edit(homework)">编辑</div>
                <div class="weui-form-preview__btn2 weui-form-preview__btn_primary" hover-class="weui-form-preview__btn_active" @click="detail(homework)">查看详情</div>
            </div>
        </div>
      </div>
  </div>
</template>

<script>
  import mpSearchbar from "mpvue-weui/src/searchbar";
  export default {
    data() {
      return {
        homeworkData: [],
        course_id: "",
        search_content: "",
        originalData: [],
        openid:wx.getStorageSync("openid"),
      };
    },
    components: {
      mpSearchbar
    },
    methods: {
      backhome(){
         wx.switchTab({ url: "/pages/index/main" });
      },
      search() {
        // console.log(this.search);
        wx.cloud.init();
        var db = wx.cloud.database();
        var that = this;
        db
          .collection("assignment")
          .where({
            course_ID: that.course_id,
            name: db.RegExp({
              regexp: that.search_content,
              options: "i"
            })
          })
          .get({
            success: function(res) {
              that.homeworkData = res.data;
              that.search_content = "";
            }
          });
      },
      fresh() {
        this.homeworkData = this.originalData;
        this.search_content = "";
      },
      addAssignment() {
        wx.navigateTo({
          url: "/pages/add_assignment/main?course_id=" + this.course_id
        });
      },
      edit(homework) {
        if (this.openid != homework._openid) {
            wx.showModal({
            title: "无法编辑",
            content: "对不起，非创建者无编辑权限",
            showCancel: false
          });
        } else {
          wx.navigateTo({
            url:
              "/pages/add_assignment/main?course_id=" +
              this.course_id +
              "&homework_id=" +
              homework._id
          });
        }
      },
      detail(homework) {
        // console.log(this.users)
        wx.navigateTo({
          url: "/pages/assignment_detail/main?homework_id=" + homework._id
        });
      }
    },
    onLoad(options) {
      this.course_id = options.course_id;
    },
    onShow() {
      wx.cloud.init();
      var that = this;
      var db = wx.cloud.database();
      var assignment = db.collection("assignment");
      assignment
        .where({
          course_ID: that.course_id
        })
        // .orderBy("time.split(' ')[0]", "asc")
        // .orderBy("time.split(' ')[1]", "desc")
        .get()
        .then(function(res) {
          that.homeworkData = res.data;
          that.originalData = res.data;
        });
    }
  };
</script>

<style>
#backhome{
  width:100px;
  height:40px;
  position: relative;
  z-index:9999;
  margin-top:19%;
  margin-left:38%;
}
.search {
  width:380px;
  margin-top:10%;
  display:inline-block;
  position: relative;
  z-index:9999;
}
#fresh{
  float:right;
  width:130px;
  height:40px;
  position: relative;
  margin:-5% 20%;
  z-index:9999;
}
#search{
  float:left;
  width:80px;
  height:40px;
  position: relative;
  margin:-5% 20%;
  z-index:9999;
}
.img {
    position: absolute;
    width: 380px;
    height:880px;
    background-image: url("https://7061-para-719569-1259337709.tcb.qcloud.la/7.jpg?sign=55dfc5f86adf1d7ca848cc8cb53a3161&t=1562221830");
    background-size: 100%;
    background-repeat: repeat;
    z-index:1;
    margin:-20% 0 0 0;
  }
textarea{
  outline:none;
  border:none;
  border-radius:20px;
  width:380px;
  list-style: none;
  position: relative;
  margin-bottom:10%;
  text-align:center;
  z-index:9999;
  height:2em;
}
button::after{
  border: 1px solid #fff;
  position: absolute;
  z-index:9999;
  border-bottom:none;
  border-left:none;
  border-top:none;
  border-right:none;
}

button{
  border-radius:30px 30px 30px 30px;
  color:#fff;
  border: 1px dashed #fff;
  background-color: #63a2d5;
  size:10%;
  font-size:30rpx;
  margin-top:50%;
  position: relative;
  z-index:9999;
  font-size:32rpx;
}

  .weui-search-bar {
    position: relative;
    padding: 16rpx 20rpx;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    background-color: #ffffff;
    border-top: 1rpx solid #ffffff;
    border-bottom: 1rpx solid #ffffff;
    margin:4% 4% 0 4%;
    z-index:9999;
    position:relative;
  }

    
  .weui-icon-search {
    margin-right: 16rpx;
    font-size: inherit;
    z-index:9999;
    position:relative;
  }

  .weui-icon-search_in-box {
    position: absolute;
    left: 20rpx;
    top: 14rpx;
    z-index:9999;
    position:relative;
  }

  .weui-search-bar__text {
    display: inline-block;
    font-size: 28rpx;
    vertical-align: middle;
    z-index:9999;
    position:relative;
  }

  .weui-search-bar__form {
    position: relative;
    -webkit-box-flex: 1;
    -webkit-flex: auto;
    flex: auto;
    border-radius: 10rpx;
    background: #fff;
    border: 1rpx solid #e6e6ea;
    z-index:9999;
    position:relative;
  }

  .weui-search-bar__box {
    position: relative;
    padding-left: 60rpx;
    padding-right: 60rpx;
    width: 100%;
    box-sizing: border-box;
    z-index: 1;
  }

  .weui-search-bar__input {
    height: 56rpx;
    line-height: 56rpx;
    font-size: 28rpx;
    z-index:9999;
    position:relative;

  }

  /*page*/

  page {
    line-height: 1.6;
    font-family: Dengxian, sans-serif;
    z-index:9999;
    position:relative;
  }
  image{

  width: 60px;
  height:60px;
  position:relative;
  margin-left:45%;

  z-index:9999;
  }

  #card{
    position: relative;
    background-color: #BCE0FD;
    border-radius: 30px 30px 30px 30px;
    margin:3% 5% 8% 5%;
    font-size:16px;
    z-index:9999;
    position:relative;
  }

  #card:before {
    top: 0;
    border-top: 1rpx solid #ffffff;
    z-index:9999;
    position:relative;
  }

  #card:after,
  #card:before {
    content: " ";
    position: absolute;
    left: 0;
    right: 0;
    height: 2rpx;
    color: #ffffff;
    z-index:9999;
    position:relative;
  }

  #card:after {
    bottom: 0;
    border-bottom: 1rpx solid #ffffff;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__value {
    font-size: 24rpx;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__value_in-hd {
    font-size: 40rpx;
    color:#2699FB;
    z-index:9999;
    position:relative;
  }

  #cardheader{
    position: relative;
    padding: 20rpx 30rpx;
    text-align: right;
    line-height: 2.5em;
    z-index:9999;
    position:relative;
  }

  #cardheader:after {
    content: " ";
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
    height: 2rpx;
    border-bottom: 1rpx solid transparent;
    color: #ffffff;
    left: 30rpx;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__bd {
    padding: 20rpx 30rpx;
    font-size: 0.9em;
    text-align: right;
    color: #2699FB;
    line-height: 2;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__ft {
    position: relative;
    line-height: 100rpx;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color:white;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__ft:after {
    content: " ";
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    height: 2rpx;
    border-top: 1rpx solid transparent;
    color:white;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__item {
    overflow: hidden;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__label {
    float: left;
    margin-right: 1em;
    min-width: 4em;
    color: #2699FB;
    text-align: justify;
    text-align-last: justify;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__value {
    display: block;
    overflow: hidden;
    word-break: normal;
    word-wrap: break-word;
    z-index:9999;
    position:relative;
    
  }

  .weui-form-preview__btn {
    position: relative;
    display: block;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background-color: #2699FB;
    text-align: center;
    border-radius:0 0 30px 30px;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn1{
    position: relative;
    display: block;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background-color: #2699FB;
    text-align: center;
    border-radius: 0 0 0 30px;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn2{
    position: relative;
    display: block;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    background-color: #2699FB;
    text-align: center;
    border-radius: 0 0 30px 0;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn:after {
    content: " ";
    position: absolute;
    left: 0;
    top: 0;
    width: 2rpx;
    bottom: 0;
    border-left: 1rpx solid transparent;
    color: #2699FB;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn:first-child:after {
    display: none;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn_active {
    background-color: #258DE6;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn_default {
    color: #ffffff;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__btn_primary {
    color:#ffffff;
    z-index:9999;
    position:relative;
  }
</style>