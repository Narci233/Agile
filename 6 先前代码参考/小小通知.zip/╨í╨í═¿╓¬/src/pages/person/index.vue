<template>
  <div>
    <div class="img">
    </div>
    <div class="allinfo">
      个人信息
    </div>
    <open-data  id="tx" type="userAvatarUrl"></open-data>
            <div class="username">
          <open-data id="nickname" type="userNickName" lang="zh_CN"></open-data>
        </div>
    <div class="card">


        <div class="create">
          <p style="font-weight:bold; margin-bottom:10px;">我创建的项目：</p>
          <div v-for="(course_data, index) in my_created_courses" :key="index">
            <div>
            <p id="p1" @click="course_details(course_data._id)">{{course_data.course}}</p>
            </div>
          </div>
        </div>
        <div class="hr"><p>-----------</p></div>
        <div class="join">
           <p style="font-weight:bold;margin-bottom:10px;">我收藏的项目：</p>
          <div v-for="(course_data, index) in my_joined_courses" :key="index">
            <p id="p2" @click="course_details(course_data.course_id)">{{course_data.course}}</p>
          </div>
        </div>
    </div>

  </div>

</template>

<script>
export default {
  data() {
    return {
      openid: wx.getStorageSync("openid"),
      my_created_courses: [],
      my_joined_courses: []
    };
  },

  methods: {
    course_details(_id) {
      wx.navigateTo({
        url: "/pages/class_detail/main?course_id=" + _id
      });
    }
  },

  onShow() {
    wx.cloud.init();
    var db = wx.cloud.database();
    var that = this;

    db
      .collection("my_courses")
      .where({
        _openid: that.openid
      })
      .get({
        success: function(res) {
          that.my_joined_courses = res.data;
        }
      });

    db
      .collection("courses")
      .where({
        _openid: that.openid
      })
      .get({
        success: function(res) {
          that.my_created_courses = res.data;
        }
      });
  }
};
</script>

<style scoped>
div {
  font-family: Dengxian;
}
.username{
  text-align:center;
  color: #2699FB;
  
}
.card {
  background-color: rgba(255, 255, 255, 0.5);
  color: #2699FB;

  width: 300px;
  z-index: 9999;
  position: relative;
  margin-top: 20px;
  margin-left: 30px;
  border-radius: 10px;
  text-align: center;
  border: 3px dashed #47749b;
}
.hr{
  margin-top:20px;
}
/* .img {
  width: 380px;
  height: 680px;
  background-image: url("https://7061-para-719569-1259337709.tcb.qcloud.la/bgwhite.jpg?sign=d340782e2ca3525c8ccfeace6e021ef8&t=1562229357");
  background-size: 100%;
  background-repeat: no-repeat;
  position: absolute;
  z-index: 1;
} */

.allinfo {
  margin-top:30px;
  text-align: center;
  color: #2699FB;
  margin-bottom:10px;
}
#tx {
  height: 50px;
  width: 50px;
  border-radius: 50%;
  display: flex;
  margin-top: 30px;
  margin-left: 160px;
  overflow: hidden;
  z-index: 9999;
}
.create{
  margin-top:20px;
}
.join {
  margin-top: 20px;
  margin-bottom:20px;
}
</style>
