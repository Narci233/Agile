<template> 
  <div>   
      <div class="weui-form-preview">
            <div class="weui-form-preview__hd">
                <div class="weui-form-preview__item">
                    <div class="weui-form-preview__label">通知名称</div>
                    <div class="weui-form-preview__value_in-hd">{{homeworkDetail.name}}</div>
                </div>
            </div>
            <div class="weui-form-preview__bd">
                <div class="weui-form-preview__item">
                    <div class="weui-form-preview__label">具体要求</div>
                    <div class="weui-form-preview__value">{{homeworkDetail.requirement}}</div>
                </div>
                <div class="weui-form-preview__item">
                    <div class="weui-form-preview__label">截止时间</div>
                    <div class="weui-form-preview__value">{{homeworkDetail.ddl}}</div>
                </div>


                <div class="weui-form-preview__item">
                    <div class="weui-form-preview__label">附件</div>
                        <image v-if="homeworkDetail.imgURL" :src="homeworkDetail.imgURL" @click="downimage()" />
                        <p @click="downfile()" >{{homeworkDetail.filename}}</p>
                </div>

            </div>
        </div>

        <!-- 评论区     -->
            <div class="weui-loadmore weui-loadmore_line">
                <div class="weui-loadmore__tips weui-loadmore__tips_in-line">评论区</div>
                <span class="weui-loadmore__tips weui-loadmore__tips_in-line" @click="show_input">点击留言</span>
            </div>

            <div v-for="(comments,index) in commentsData" :key="index">
              
               <div class="user">
                <span style="display:block;float:left"><image id="tx" :src="comments.img" class="open-data-userAvatarUrl" /> 
                </span>{{comments.user}} 
               </div>
               <div class="time">
                 {{comments.time}}
               </div>
               <div class="comment">
                {{comments.comment}}
               </div>
               

               <div class="reply" @click="show_reply(index)">回复</div>

                <div v-for="(replies,index2) in replyData" :key="index2">
                  <div @click="show_third_reply(index,index2)">
                    <div class="re-reply">
                     <div v-if="comments._id==replies.answer_id" >
                        <div v-if="comments.user==replies.answer_name">      
                          {{replies.ask}} ： {{replies.reply}}
                        </div>
                        
                        <div  v-else>
                          {{replies.ask}} 回复 {{replies.answer_name}} ： {{replies.reply}}
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
            <div  class='commentInput' v-if="focusInput" style="focusInput?'margin-botttom:60rpx':''">
                <!-- <input class='input' maxlength='-1' v-model="comment" bindfocus="inputFocus" bindblur="blurInput" fixed="true"  style="cursor-spacing:'20'" placeholder="我要写评论">
                <button class='send'>发送</button>  @focus="focusInput" @blur="blurInput" -->
                <mp-input placeholder="评论" v-model="comment" cursorSpacing='20px' type='text' confirmType="send" focus="focus" @confirm="add_comment"></mp-input>
            </div>    

            <div class='commentInput' v-if="focusAsk" style="focusAsk?'margin-botttom:60rpx':''">
                <mp-input placeholder="回复" v-model="reply" cursorSpacing='20px' type='text' confirmType="send" focus="focus" @confirm="add_reply"></mp-input>
            </div>    

            
  </div>
</template>

<script>
  import mpInput from "mpvue-weui/src/input";
  export default {
    data() {
      return {
        homeworkDetail: [],
        commentsData: [],
        replyData: [],
        focusInput: false,
        focusAsk: false,
        //   inputMar: false,
        comment: "",
        reply: "",
        answer_id: "",
        answer_name: "",
        focus: true,
        download: "",
        downloadimg: ""
      };
    },
    components: {
      mpInput
    },
    methods: {
      show_input() {
        this.focusInput = true;
      },
      show_reply(index) {
        this.focusAsk = true;
        this.answer_id = this.commentsData[index]._id;
        this.answer_name = this.commentsData[index].user;
      },
      show_third_reply(index, index2) {
        this.focusAsk = true;
        this.answer_id = this.commentsData[index]._id;
        this.answer_name = this.replyData[index2].ask;
      },
      add_comment() {
        wx.cloud.init();
        var db = wx.cloud.database();
        var comments = db.collection("comments");
        var that = this;
        var date = new Date();
        var myDate =
          date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
        var myTime = date.getHours() + ":" + date.getMinutes();
        comments.add({
          data: {
            assignment_id: that.homeworkDetail._id,
            comment: that.comment,
            time: myDate + " " + myTime,
            user: wx.getStorageSync("users").name,
            img: wx.getStorageSync("users").img
          },
          success: function(res) {
            wx.showToast({
              title: "评论成功",
              duration: 1500,
              success: function(res) {
                setTimeout(function() {
                  wx.redirectTo({
                    url:
                      "/pages/assignment_detail/main?homework_id=" +
                      that.homeworkDetail._id
                  });
                }, 1500);
              }
            });
          }
        });
        this.comment = "";
        this.focusInput = false;
        this.focus = false;
      },
      add_reply(index) {
        wx.cloud.init();
        var db = wx.cloud.database();
        var reply = db.collection("reply");
        var that = this;
        var date = new Date();
        var myDate =
          date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
        var myTime = date.getHours() + ":" + date.getMinutes();
        reply.add({
          data: {
            answer_id: that.answer_id,
            reply: that.reply,
            time: myDate + " " + myTime,
            ask: wx.getStorageSync("users").name,
            // img: wx.getStorageSync("users").img,
            answer_name: that.answer_name
          },
          success: function(res) {
            wx.showToast({
              title: "留言成功",
              duration: 1500,
              success: function(res) {
                setTimeout(function() {
                  wx.redirectTo({
                    url:
                      "/pages/assignment_detail/main?homework_id=" +
                      that.homeworkDetail._id
                  });
                }, 1500);
              }
            });
          }
        });
        this.reply = "";
        this.focusAsk = false;
        this.focus = false;
      },
      //  下载查看word，Excel，pptx文件
      downfile() {
        var that = this;
        wx.cloud.downloadFile({
          fileID: that.homeworkDetail.fileURL, // 文件 ID
          success(res) {
            // console.log(res.tempFilePath)
            wx.openDocument({
              filePath: res.tempFilePath,
              success: function(res) {
                console.log("打开文档成功");
              }
            });
          },
          fail: err => {
            console.log(err);
          }
        });
      },
      downimage() {
        var that = this;
        wx.cloud.downloadFile({
          fileID: that.homeworkDetail.imgURL, // 文件 ID
          success(res) {
            // 返回临时文件路径
            // console.log(res.tempFilePath);
            wx.previewImage({
              current: res.tempFilePath, // 当前显示图片的http链接
              urls: [res.tempFilePath] // 需要预览的图片http链接列表
            });
          },
          fail: err => {
            console.log(err);
          }
        });
      },
      blurInput(e) {
        //   msg = e.detail.value,
        inputMar = false;
      }
      // inputFocus() {
      //   inputMar = true;
      // }
    },
    onLoad(options) {
      this.reply = "";
      this.focusInput = false;
      this.focusAsk = false;
      this.focus = false;
      // 根据作业ID筛选
      var that = this;
      wx.cloud.init();
      var db = wx.cloud.database();
      db
        .collection("assignment")
        .where({
          _id: options.homework_id
        })
        .get({
          success: function(res) {
            that.homeworkDetail = res.data[0];
            // console.log(that.homeworkDetail._id)
          }
        });

      // 留言
      wx.cloud.init();
      var that = this;
      var db = wx.cloud.database();
      var comments = db.collection("comments");
      comments
        .where({ assignment_id: options.homework_id })
        .get()
        .then(function(res) {
          that.commentsData = res.data;
        });

      var reply = db.collection("reply");
      reply
        // .orderBy("time.split(' ')[0]", "desc")
        // .orderBy("time.split(' ')[1]", "desc")
        .get()
        .then(function(res) {
          that.replyData = res.data;
        });
    }
  };
</script>

<style>
.re-reply{
  width:380px;
  text-align:center;
  margin-left:10px;

}
.user{
  margin-left:20%;
  font-color:#2699FB;
}
.time{
  margin-left:20%;
  font-size:12px;
  font-color:#2699FB;
}
.reply{
  color:#565656;
  float:right;
  margin-right:20px;
  font-size:14px;
}
.commentInput{
  font-family:Dengxian;
}
.comment{

}
#tx{
  height:50px;
  width:50px;
  border-radius:50%;
  overflow:hidden;
  position: relative;
  z-index:9999;
  margin-right:10px;
  margin-left:-20px;
}
.weui-loadmore__tips {
  display: inline-block;
  vertical-align: middle;
}

.weui-loadmore_line {
  border-top: 2rpx solid #e5e5e5;
  margin-top: 2.4em;
}

.weui-loadmore__tips_in-line {
  position: relative;
  top: -.9em;
  padding: 0 0.55em;
  background-color: #fff;
  color: #999;
}

.weui-loadmore__tips_in-dot {
  position: relative;
  padding: 0 0.16em;
  width: 8rpx;
  height: 1.6em;
}

.weui-loadmore__tips_in-dot:before {
  content: " ";
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -2rpx;
  margin-left: -4rpx;
  width: 8rpx;
  height: 8rpx;
  border-radius: 50%;
  background-color: #e5e5e5;
}
page{
    font-family:Dengxian;
}
.weui-form-preview {
  position: relative;
  background-color: #BCE0FD;
  border-radius: 30px 30px 30px 30px;
  margin:4%;
  font-size:16px;
}

.weui-form-preview:before {
  top: 0;
  border-top: 1rpx solid #ffffff;

}

.weui-form-preview:after,
.weui-form-preview:before {
  content: " ";
  position: absolute;
  left: 0;
  right: 0;
  height: 2rpx;
  color: #ffffff;
}

.weui-form-preview:after {
  bottom: 0;
  border-bottom: 1rpx solid #ffffff;
}

.weui-form-preview__value {
  font-size: 28rpx;
}

.weui-form-preview__value_in-hd {
  font-size: 52rpx;
  color:#2699FB;
}

.weui-form-preview__hd {
  position: relative;
  padding: 20rpx 30rpx;
  text-align: right;
  line-height: 2.5em;
}

.weui-form-preview__hd:after {
  content: " ";
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  height: 2rpx;
  border-bottom: 1rpx solid transparent;
  color: #ffffff;
  left: 30rpx;

}

.weui-form-preview__bd {
  padding: 20rpx 30rpx;
  font-size: 0.9em;
  text-align: right;
  color: #2699FB;
  line-height: 2;
}

.weui-form-preview__ft {
  position: relative;
  line-height: 100rpx;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  color:white;
}

.weui-form-preview__ft:after {
  content: " ";
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  height: 2rpx;
  border-top: 1rpx solid transparent;
  color:white;
}

.weui-form-preview__item {
  overflow: hidden;
}

.weui-form-preview__label {
  float: left;
  margin-right: 1em;
  min-width: 4em;
  color: #2699FB;
  text-align: justify;
  text-align-last: justify;
}

.weui-form-preview__value {
  display: block;
  overflow: hidden;
  word-break: normal;
  word-wrap: break-word;
}

.weui-form-preview__btn {
  position: relative;
  display: block;
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  background-color: #2699FB;
  text-align: center;
  border-radius:0 0 30px 30px;

}

.weui-form-preview__btn1{
  position: relative;
  display: block;
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  background-color: #2699FB;
  text-align: center;
  border-radius: 0 0 0 30px;
}

.weui-form-preview__btn2{
  position: relative;
  display: block;
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  background-color: #2699FB;
  text-align: center;
  border-radius: 0 0 30px 0;
}

.weui-form-preview__btn:after {
  content: " ";
  position: absolute;
  left: 0;
  top: 0;
  width: 2rpx;
  bottom: 0;
  border-left: 1rpx solid transparent;
  color: #2699FB;
}

.weui-form-preview__btn:first-child:after {
  display: none;
}

.weui-form-preview__btn_active {
  background-color: #1F527E;
}

.weui-form-preview__btn_default {
  color: #ffffff;
}

.weui-form-preview__btn_primary {
  color:#ffffff;
}
</style>