<template>
  <div>
    <div class="img">
    </div>
    <div class="title">新建项目</div>
    <div class="card1">
      <textarea placeholder-style='color:rgb(128, 128, 128)' v-model="course" style="margin-top:10px;" placeholder="请输入课程名"></textarea>
    </div>
    <div class="card2">
      <textarea placeholder-style='color:rgb(128, 128, 128)' v-model="teacher" style="margin-top:10px;" placeholder="请输入创建者"></textarea>
    </div>
    <div class="card3">
      <textarea placeholder-style='color:rgb(128, 128, 128)' v-model="description" placeholder="项目内容描述" name="textarea" style="margin-top:10px;"/>
    </div>
    <button  @click="submit"> 提交 </button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        course:"",
        teacher:"",
        description:"",
        coursesData:[]
      };
    },

    methods: {
      uploadCourse(course, teacher, description) {
        var db = wx.cloud.database();
        var courses = db.collection("courses");
        courses.add({
          data: {
            course: course,
            teacher: teacher,
            description: description
          }
        })
      },
      submit() {
        var that = this;
        if (that.course == ""){
          wx.showModal({
            title: '提示',
            content: '项目名不可为空',
            showCancel: false,
            success (res) {
            }
          })
        }
        else if (that.teacher == ""){
          wx.showModal({
            title: '提示',
            content: '创建者不可为空',
            showCancel: false,
            success (res) {
            }
          })
        }
        else {
          that.uploadCourse(that.course, that.teacher, that .description);
          wx.navigateBack()
        }
      }
    },

    onLoad(option) {
      this.course = ""
      this.teacher = ""
      this.description = ""
      wx.cloud.init()
    }
  };
</script>

<style scoped>
.title{
  text-align:center;
  margin:10%;
  color:#258DE6;
}
div{
  font-family:Dengxian;
}
button::after{
  border:none;
}
textarea{
  text-align:center;
  color:#258DE6;
}
input{
  text-align:center;
  outline:none;

  list-style: none;
}
button{
  border-radius:30px 30px 30px 30px;
  color:#2699FB;
  size:100%;
  margin:20% 35% 15%;
  border: none; 
  width:100px;
  z-index:9999;
  font-size:35rpx;
  position:center;
}
.card1{
  background-color:none;
  margin:0 5% 0 5%;
  height:65px;
  border:1px dashed #9cc6e9;
  border-radius:10px 10px 10px 10px;
}
.card2{
  background-color:none;
  margin:5% 5% 0 5%;
  height:65px;
  border:1px dashed #9cc6e9;
  border-radius:10px 10px 10px 10px;
}
.card3{
  background-color:none;
  margin:5% 5% 0 5%;
  height:115px;
  border:1px dashed #9cc6e9;
  border-radius:10px 10px 10px 10px;
}
</style>
