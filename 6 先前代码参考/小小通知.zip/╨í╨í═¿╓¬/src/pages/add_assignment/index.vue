<template> 
   <div>
    <div id="card">

      <div class="weui-cells__title">通知详情</div>
        <div class="weui-cells weui-cells_after-title">
            <div class="weui-cell weui-cell_input">
            </div>
            <div class="weui-cell weui-cell_input">
                <div class="weui-cell__hd">
                    <div class="weui-label">通知名称</div>
                </div>
                <div class="weui-cell__bd">
                    <textarea  v-model="name" placeholder="请输入通知名称"/>
                </div>
            </div>
            <div class="weui-cell weui-cell_input">
                <div class="weui-cell__hd">
                    <div class="weui-label">截止日期</div>
                </div>
                <div class="weui-cell__bd">
                    <picker mode="date" value="date"  start="date" end="2200-01-01" @change="dateChange">
                        <view class="weui-input">{{date}}</view>
                    </picker>
                </div>
            </div>
              <div class="weui-cell weui-cell_input">
                <div class="weui-cell__hd">
                    <div class="weui-label">截止时间</div>
                </div>
                <div class="weui-cell__bd">
                    <picker mode="time" value="time" start="00:00" end="23:59" @change="timeChange">
                        <view class="weui-input">{{time}}</view>
                    </picker>
                </div>



              
            </div>
      <div class="div2">
      <div class="weui-cells__title">具体要求</div>
        <div class="weui-cells weui-cells_after-title">
          <div class="weui-cell">
              <div class="weui-cell__bd">
                  <textarea class="weui-textarea" v-model="requirement" placeholder="请输入具体要求" style="height: 5em" />
              </div>
        </div>
    </div>
            <div id="div5" class="weui-cells__title">文件上传</div> 
              <image v-if="imgPath" :src="imgPath"  />  <image v-if="chooseImg" :src="chooseImg"  />
              <p>{{filename}}</p>
              <button @click ="chooseImage">选择图片</button>
              <button @click ="chooseFile">选择文件</button>
              <p id="warn">仅可上传pptx, docx, xlsx</p>

        </div>
      </div>


      
      <div v-if="homeworkDetail._id" class="weui-form-preview__ft">
        <button id="btnleft" @click="update">修改</button>
        <button id="btnright"  @click="deleteHomework">删除</button>
      </div>

      <div v-else>
        <button id="btn3" @click="submit">发布</button>
      </div>

    </div>
    </div>

</template>

<script>
var date = new Date();
if (date.getMonth() < 10) {
  var month = date.getMonth() + 1;
  month = "0" + month;
} else {
  var month = date.getMonth() + 1;
}
if (date.getDate() < 10) {
  var day = "0" + date.getDate();
} else {
  var day = date.getDate();
}
var myDate = date.getFullYear() + "-" + month + "-" + day;
var myTime = date.getHours() + ":" + date.getMinutes();

export default {
  data() {
    return {
      homeworkDetail: [],
      date: myDate,
      time: myTime,
      name: "",
      requirement: "",
      course_id: "",
      imgPath: "",
      filePath: "",
      filename: "",
      chooseImg: "",
      chooseFilePath: "",
      openid: wx.getStorageSync("openid")
    };
  },
  components: {},
  methods: {
    showTimePicker() {
      this.$refs.mpPicker.show();
    },
    showDatePicker() {
      this.$refs.mpDatePicker.show();
    },
    dateChange: function(e) {
      this.date = e.mp.detail.value;
    },
    timeChange: function(e) {
      this.time = e.mp.detail.value;
    },
    // 图片选择
    chooseImage() {
      var that = this;
      wx.chooseImage({
        success: function(res) {
          that.chooseImg = res.tempFilePaths[0];
          // console.log(that.chooseImg);
          wx.cloud.init();
        }
      });
    },
    //  客户端文件选择
    chooseFile() {
      var that = this;
      wx.chooseMessageFile({
        success: function(res) {
          that.chooseFilePath = res.tempFiles[0].path;
          that.filename = res.tempFiles[0].name;
          // console.log(that.chooseFilePath);
          wx.cloud.init();
        }
      });
    },
    getURL() {
      var file_name1 = this.filePath;
      var file_name2 = this.imgPath;
      // console.log(this.filePath, this.imgPath);
      if (this.chooseFilePath) {
        var splitfile_paths1 = this.chooseFilePath.split("/");
        // console.log(splitfile_paths1);
        var that = this;
        wx.cloud
          .uploadFile({
            cloudPath: splitfile_paths1[splitfile_paths1.length - 1],
            filePath: that.chooseFilePath
          })
          .then(function(res) {
            console.log(res);
            file_name1 = res.fileID;
            file_name2 = "";
            if (!that.homeworkDetail._id) {
              if (that.name == "") {
                wx.showModal({
                  title: "提示",
                  content: "通知名不可为空",
                  showCancel: false,
                  success(res) {}
                });
              } else {
                that.submitfile(file_name1, file_name2);
              }
            } else {
              if (that.name == "") {
                wx.showModal({
                  title: "提示",
                  content: "通知名不可为空",
                  showCancel: false,
                  success(res) {}
                });
              } else {
                that.updatefile(file_name1, file_name2);
              }
            }
          });
      } else if (this.chooseImg) {
        var splitimg_paths2 = this.chooseImg.split("/");
        // console.log(splitimg_paths2);
        var that = this;
        wx.cloud
          .uploadFile({
            cloudPath: splitimg_paths2[splitimg_paths2.length - 1],
            filePath: that.chooseImg
          })
          .then(function(res) {
            file_name2 = res.fileID;
            file_name1 = "";
            that.filename = "";
            if (!that.homeworkDetail._id) {
              if (that.name == "") {
                wx.showModal({
                  title: "提示",
                  content: "通知名不可为空",
                  showCancel: false,
                  success(res) {}
                });
              } else {
                that.submitfile(file_name1, file_name2);
              }
            } else {
              if (that.name == "") {
                wx.showModal({
                  title: "提示",
                  content: "通知名不可为空",
                  showCancel: false,
                  success(res) {}
                });
              } else {
                that.updatefile(file_name1, file_name2);
              }
            }
          });
      } else {
        // console.log("no choosing path");
        if (!this.homeworkDetail._id) {
          if (this.name == "") {
            wx.showModal({
              title: "提示",
              content: "通知名不可为空",
              showCancel: false,
              success(res) {}
            });
          } else {
            this.submitfile(file_name1, file_name2);
          }
        } else {
          if (this.name == "") {
            wx.showModal({
              title: "提示",
              content: "通知名不可为空",
              showCancel: false,
              success(res) {}
            });
          } else {
            this.updatefile(file_name1, file_name2);
          }
        }
      }
    },
    submitfile(file_name1, file_name2) {
      var deadline = this.date + " " + this.time;
      var that = this;
      var db = wx.cloud.database();
      var assignment = db.collection("assignment");
      assignment.add({
        data: {
          course_ID: that.course_id,
          name: that.name,
          ddl: deadline,
          requirement: that.requirement,
          fileURL: file_name1,
          filename: that.filename,
          imgURL: file_name2
        },
        success: function(res) {
          wx.showToast({
            title: "添加成功",
            duration: 1500,
            success: function(res) {
              setTimeout(function() {
                wx.navigateTo({
                  url: "/pages/assignment/main?course_id=" + that.course_id
                });
              }, 1500);
            }
          });
        }
      });
    },
    updatefile(file_name1, file_name2) {
      var deadline = this.date + " " + this.time;
      var db = wx.cloud.database();
      var that = this;
      // if (that.openid != that.homeworkDetail._openid) {
      //   wx.showModal({
      //     title: "无法修改",
      //     content: "对不起，非创建者无修改权限",
      //     showCancel: false
      //   });
      // } else {
        db
          .collection("assignment")
          .doc(this.homeworkDetail._id)
          .update({
            data: {
              course_ID: that.course_id,
              name: that.name,
              ddl: deadline,
              requirement: that.requirement,
              fileURL: file_name1,
              filename: that.filename,
              imgURL: file_name2
            },
            success: function(res) {
              wx.showToast({
                title: "更新成功",
                duration: 1500,
                success: function(res) {
                  setTimeout(function() {
                    wx.navigateTo({
                      url: "/pages/assignment/main?course_id=" + that.course_id
                    });
                  }, 1500);
                }
              });
            }
          });
      // }
    },
    submit() {
      this.getURL();
    },
    update() {
      this.getURL();
    },
    deleteHomework() {
      var that = this;
      wx.showModal({
        title: "删除通知",
        content: "确定要删除该通知？",
        showCancel: true,
        success: function(res) {
          if (res.cancel) {
            //点击取消,默认隐藏弹框
          } else {
            //点击确定
            // if (that.openid != that.homeworkDetail._openid) {
            //   wx.showModal({
            //     title: "无法删除",
            //     content: "对不起，非创建者无删除权限",
            //     showCancel: false
            //   });
            // } else {
              var db = wx.cloud.database();
              db
                .collection("assignment")
                .doc(that.homeworkDetail._id)
                .remove({
                  success: function(res) {
                    wx.navigateTo({
                      url: "/pages/assignment/main?course_id=" + that.course_id
                    });
                  }
                });
            }
          // }
        }
      });
    }
  },
  onLoad(options) {
    this.homeworkDetail = [];
    this.date = myDate;
    this.time = myTime;
    this.name = "";
    this.requirement = "";
    this.course_id = options.course_id;
    this.imgPath = "";
    this.filePath = "";
    this.filename = "";
    this.chooseImg = "";
    wx.cloud.init();
    var that = this;
    if (options.homework_id) {
      var db = wx.cloud.database();
      db
        .collection("assignment")
        .where({
          _id: options.homework_id
        })
        .get({
          success: function(res) {
            that.homeworkDetail = res.data[0];
            that.date = res.data[0].ddl.split(" ")[0];
            that.time = res.data[0].ddl.split(" ")[1];
            that.name = res.data[0].name;
            that.requirement = res.data[0].requirement;
            that.course_id = res.data[0].course_ID;
            that.imgPath = res.data[0].imgURL;
            that.filePath = res.data[0].fileURL;
            that.filename = res.data[0].filename;
          }
        });
    }
  }
};
</script>

<style>
.weui-form-previe__ft{
  margin:20px;
  border:none;
  background-color:#fff;
  border:#fff;
}
#warn {
  color: #4d4d4d;
  text-align: center;
}
div {
  font-family: Dengxian;
}
button::after {
  border: none;
  border-top:none;
  border-left:none;
}

  .weui-form-preview__ft {
    position: relative;
    line-height: 100rpx;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    color:white;
    z-index:9999;
    position:relative;
  }

  .weui-form-preview__ft:after {
    content: " ";
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    height: 2rpx;
    border-top: 1rpx solid transparent;
    color:white;
    z-index:9999;
    position:relative;
  }

textarea {
  outline: none;
  border: 1px solid #fff;
  border-radius: 20px;
  width: 280px;
  list-style: none;
  position: relative;
  z-index: 9999;
  height: 3em;
  margin-top:25px;
}
#div5 {
  width: 5em;
  text-align: center;
  margin-left: 30%;
}

input {
  font-family: Dengxian;
}
#btnleft {
  background-color: #2699fb;
  color: white;
  border-radius:10px 10px 10px 10px;
  margin-top:20px;
  margin-left:60px;
  margin-right:10px;
  border-left:none;
  border-top:none;
}
#btnright {
  background-color: #2699fb;
  color: white;
  margin-right:10px;
  border-radius:10px 10px 10px 10px;
  margin-top:20px;
  border-top:none;
}
#btn3 {
  background-color: #2699fb;
  color: white;
}
#homeworktext {
  height: 5em;
  margin: 5%;
}
#card {
  border-color: green;
  margin: 5% 10% 5% 10%;
}
page {
  font-family: Dengxian;
}
#homeworkname {
  margin: 5% 5% 15% 5%;
  text-align: center;
}

.weui-cells {
  position: relative;
  margin-top: 1.17647059em;
  background-color: #fff;
  line-height: 1.41176471;
  font-size: 34rpx;
}

.weui-cells:before {
  top: 0;
  border-top: 1rpx solid #fff;
}

.weui-cells:after,
.weui-cells:before {
  content: " ";
  position: absolute;
  left: 0;
  right: 0;
  height: 2rpx;
  color: #fff;
}

.weui-cells:after {
  bottom: 0;
  border-bottom: 1rpx solid #fff;
}

.weui-cells__title {
  margin-top: 0.77em;
  margin-bottom: 0.3em;
  padding-left: 30rpx;
  padding-right: 30rpx;
  color: #2699fb;
  font-size: 36rpx;
  text-align: center;
}

.weui-cells_after-title {
  margin-top: 0;
}

.weui-cells__tips {
  margin-top: 0.3em;
  color: #fff;
  padding-left: 30rpx;
  padding-right: 30rpx;
  font-size: 28rpx;
}

.weui-cell {
  padding: 20rpx 30rpx;
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
}

.weui-cell:before {
  content: " ";
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  height: 2rpx;
  border-top: 1rpx solid #fff;
  color: #fff;
  left: 30rpx;
}

.weui-cell:first-child:before {
  display: none;
}

.weui-cell_active {
  background-color: #ececec;
}

.weui-cell_primary {
  -webkit-box-align: start;
  -webkit-align-items: flex-start;
  align-items: flex-start;
}

.weui-cell__bd {
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
}

.weui-cell__ft {
  text-align: right;
  color: #999;
}

.weui-cell_access {
  color: inherit;
}

.weui-cell__ft_in-access {
  padding-right: 26rpx;
  position: relative;
}

.weui-cell__ft_in-access:after {
  content: " ";
  display: inline-block;
  height: 12rpx;
  width: 12rpx;
  border-width: 4rpx 4rpx 0 0;
  border-color: #c8c8cd;
  border-style: solid;
  -webkit-transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
  position: relative;
  top: -4rpx;
  position: absolute;
  top: 50%;
  margin-top: -8rpx;
  right: 4rpx;
}

.weui-cell_link {
  color: #586c94;
  font-size: 28rpx;
}

.weui-cell_link:active {
  background-color: #ececec;
}

.weui-cell_link:first-child:before {
  display: block;
}

button {
  margin: 5% 10% 5% 10%;
  border-radius: 30px 30px 30px 30px;
  background-color: #fff;
  border-color: none;
  border-left: 1rpx solid #fff;
  font-size: 36rpx;
}
image {
  height: 50px;
  width: 50px;
  position: center;
  margin-left: 130px;
  border-radius: 50%;
  display: flex;
  overflow: hidden;
}
</style>