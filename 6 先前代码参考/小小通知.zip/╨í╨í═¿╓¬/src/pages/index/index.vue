<template>
  <div>
    <div class="img">
    </div>
    <span class="type">
      <textarea placeholder-style="border-radius:10px;color:#2699FB;font-size:16px" v-model="search_content" placeholder="请输入项目名称" />
       </span>

    <div class="search">
 
        <button id="search" @click="search">搜索</button>
   
        <button id="fresh" @click="fresh">查看所有项目</button>
    </div>

    <div class="add">
      <navigator url="/pages/addclass/main" hover-class="navigator-hover">
        <image id="add" src="/static/images/add.png" />
      </navigator>
    </div>
    <div class="below">
      <div id="big">
        <p>项目列表</p>
        <p>------</p>
      </div>

      <div class="coursetext" v-for="(course_data, index) in coursesData" :key="index">
          <p id="coursetitle" @click="course_details(course_data._id)">{{course_data.course}}</p>
          <p id="courseteacher" >{{course_data.teacher}}</p>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        coursesData: [],
        search_content: "",
        all_courses: [],
        openid: ""
      };
    },

    methods: {
      course_details(course_id) {
        wx.navigateTo({
          url: "/pages/class_detail/main?course_id=" + course_id
        });
      },

      search() {
        // console.log(this.search);
        wx.cloud.init();
        var db = wx.cloud.database();
        var that = this;
        db
          .collection("courses")
          .where({
            course: db.RegExp({
              regexp: that.search_content,
              options: "i"
            })
          })
          .get({
            success: function(res) {
              that.coursesData = res.data;
              that.search_content = "";
            }
          });
      },

      fresh() {
        this.coursesData = this.all_courses;
        this.search_content = "";
      },
      getOpenid() {
        var that = this;
        wx.cloud.callFunction({
          name: "cloud",
          complete(res) {
            // console.log("云函数获取到的openid: ", res.result.openid);
            var openid = res.result.openid;
            wx.setStorageSync("openid", openid);
            that.openid = openid;
          }
        });
      }
    },
    onShow() {
      wx.cloud.init();
      var db = wx.cloud.database();
      var that = this;
      db
        .collection("courses")
        .orderBy("_id", "desc")
        .get()
        .then(function(res) {
          that.coursesData = res.data;
          that.all_courses = res.data;
        });
    },
    onLoad() {
      wx.cloud.init();
      this.getOpenid();
    } // 获取用户openid
  };
</script>

<style scoped>
div{
  font-family:Dengxian;
  position: absolute;
  color:#2699FB;
  z-index:9999;
}
.img {
    width: 380px;
    height:680px;
    background-image: url("https://7061-para-719569-1259337709.tcb.qcloud.la/bgwhite.jpg?sign=d340782e2ca3525c8ccfeace6e021ef8&t=1562229357");
    background-size: 100%;
    background-repeat: repeat-y;
    position: absolute;
    z-index:1;
  }
.type{
  font-size:28rpx;
  text-align:center;
  width:380px;
  position: relative;
  z-index:9999;
}
.search {
  width:380px;
  display:inline-block;
  position: relative;
  margin-top:10%;
  margin-bottom:10%;
  z-index:9999;
}
#fresh{
  float:right;
  width:130px;
  height:35px;
  font-size:16px;
  position: relative;
  margin:-5% 20%;
  z-index:9999;
}
#search{
  float:left;
  font-size:16px;
  width:80px;
  height:35px;
  position: relative;
  margin:-5% 20%;
  z-index:9999;
}
textarea{
  outline:none;
  border:none;
  border-radius:20px;
  width:180px;
  list-style: none;
  position: relative;
  margin-top:40%;
  margin-left:27%;
  z-index:9999;
  height:2em;
}
#add {

  width: 60px;
  height:60px;
  position:relative;

  margin-left:270%;
  z-index:9999;
}
.classname{
  background-color:#2699FB;
  text-align:center;
  width:18em;
  height:3em;
  position: absolute;
  z-index:9999;
}

.coursetext{
  margin-top:10%;
  margin-left:10%;
  margin-bottom:20px;
  width:280px;
 color:#2699FB;
  position: relative;
 z-index:9999;
 text-align:center;
}
button::after{
  border: 1px solid #2699FB;
  position: absolute;
  z-index:9999;
  border-bottom:none;
  border-right:none;
  border-top:none;
  border-left:none;
}

button{
  border-radius:30px 30px 30px 30px;
  color:#2699FB;
  border: 1px dashed #2699FB;
  background-color: #fff;
  size:10%;
  font-size:16rpx;
  margin-top:60%;
  position: relative;
  z-index:9999;
  font-size:32rpx;
}
.below{
  border:3px dashed #47749b;
  width:290px;
  margin-top:28%;
  margin-left:40px;
  border-radius:10px;
  margin-bottom:40px;
}
#big{
  color:#2699FB;
  font-size:36rpx;
  width:290px;
  text-align:center;
  margin-top:5%;
  position: relative;
  z-index:9999;
}
navigator::active{
  color:#2699FB;  
  position: absolute;
  z-index:9999;
}
#coursetitle{
  width:290px;
  font-size:36rpx;
  font-weight:bold;
  color:#2699FB;
  text-align:center;
  margin-left:-12%;
}
#courseteacher{
  width:290px;
  color:#2699FB;
  font-size:28rpx;
  margin-left:-12%;
}
</style>
